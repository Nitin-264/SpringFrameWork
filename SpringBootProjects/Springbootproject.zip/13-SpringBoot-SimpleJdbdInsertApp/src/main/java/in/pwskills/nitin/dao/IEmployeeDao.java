package in.pwskills.nitin.dao;

import java.util.List;

import in.pwskills.nitin.bean.EmployeeBO;

public interface IEmployeeDao {

	public int insertrecord(EmployeeBO bo);
}
