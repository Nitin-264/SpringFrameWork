package in.pwskills.nitin.service;

import java.util.List;

import in.pwskills.nitin.bean.EmployeeDTO;

public interface IEmployeeService {

	public int insertrecord(EmployeeDTO dto);
}
